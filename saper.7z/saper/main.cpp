#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <chrono>                  //biblioteka sluzaca do mierzenia czasu

using namespace std;
using namespace chrono;

struct Pole {
    bool bomba = false, odkryte = false, flaga = false;
    int sasiad = 0;                             //sasiad, czyli pola obok
};

class Saper {
    vector<vector<Pole>> mapa;
    int wiersze, kolumny, bomby;
    bool gra = true, wygrana = false;
    time_point<steady_clock> start;

public:
    Saper(int poziom) {
        if (poziom == 1)      { wiersze = 5; kolumny = 5; bomby = 5; }            //poziom 1
        else if (poziom == 2) { wiersze = 8; kolumny = 8; bomby = 12; }           //poziom 2
        else                  { wiersze = 10; kolumny = 10; bomby = 20; }         //poziom 3

        mapa.resize(wiersze, vector<Pole>(kolumny));
        srand(time(0));
        start = steady_clock::now();                //zegar start

                                                      // Rozstawianie bomb przez losowanie
        for (int i = 0, x, y; i < bomby;) {
            x = rand() % wiersze;
            y = rand() % kolumny;
            if (!mapa[x][y].bomba) {
                mapa[x][y].bomba = true;
                i++;
            }
        }

                                                         // Obliczanie sąsiadów
        for (int i = 0; i < wiersze; i++)
            for (int j = 0; j < kolumny; j++)
                if (!mapa[i][j].bomba)
                    for (int dx = -1; dx <= 1; dx++)
                        for (int dy = -1; dy <= 1; dy++) {
                            int ni = i + dx, nj = j + dy;
                            if (ni >= 0 && ni < wiersze && nj >= 0 && nj < kolumny)
                                mapa[i][j].sasiad += mapa[ni][nj].bomba;
                        }
    }

    void wyswietl() {
        cout << "\n   ";
        for (int j = 0; j < kolumny; j++) cout << j << " ";
        cout << "\n";
        for (int i = 0; i < wiersze; i++) {
            cout << i << " ";
            for (int j = 0; j < kolumny; j++) {
                if (mapa[i][j].flaga)        cout << "F ";       //FLAGA GRACZA
                else if (!mapa[i][j].odkryte) cout << "# ";      //ukryte pole
                else if (mapa[i][j].bomba)    cout << "* ";      //BOMBA
                else if (mapa[i][j].sasiad)   cout << mapa[i][j].sasiad << " "; //liczba ile bomb w poblizu
                else                          cout << ". "; //puste pole
            }
            cout << "\n";
        }
    }

    void odkryj(int x, int y) {                                              //odkrywanie pól i flag
        if (x < 0 || x >= wiersze || y < 0 || y >= kolumny) return;
        if (mapa[x][y].odkryte || mapa[x][y].flaga) return;

        mapa[x][y].odkryte = true;
        if (mapa[x][y].bomba) { gra = false; return; }

        if (mapa[x][y].sasiad == 0)
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = -1; dy <= 1; dy++)
                    odkryj(x + dx, y + dy);
    }

    void flaga(int x, int y) {                                                //Gracz może postawić lub zdjąć flagę na polu
        if (!mapa[x][y].odkryte) mapa[x][y].flaga = !mapa[x][y].flaga;
    }

    void sprawdzWygrana() {                       //sprawdzenie czy wygrana
        int odkryte = 0;
        for (auto& r : mapa)
            for (auto& p : r)
                if (p.odkryte) odkryte++;
        if (odkryte == wiersze * kolumny - bomby) {
            gra = false;
            wygrana = true;
        }
    }

    void graj() {
        while (gra) {
            wyswietl();
            int op, x, y;
            cout << "\n1 - Odkryj, 2 - Flaga\nOpcja i współrzędne: ";
            cin >> op >> x >> y;
            if (op == 1) odkryj(x, y);
            else if (op == 2) flaga(x, y);
            sprawdzWygrana();
        }

        wyswietl();
        auto czas = duration_cast<seconds>(steady_clock::now() - start).count();
        if (wygrana) cout << "\n🎉 Wygrana w " << czas << " sekund! 🎉\n";
        else         cout << "\n💥 BOOM! Przegrana. 💥\n";

        // Info o autorze
        cout << "\n=== AUTORZY ===\n";
        cout << "Mateusz Biskup, Przemysław Błaszczyk, Kacper Kałuża\n";
        cout << "Kierunek: Informatyka\n";
        cout << "Rok: I, Semestr: 2\n";
        cout << "ALL RIGHTS RESERVED © 2025\n";
    }
};

int main() {
    int poziom;
    cout << "=== SAPER ===\n";
    cout << "1. Łatwy\n2. Średni\n3. Trudny\nWybierz poziom: ";
    cin >> poziom;

    Saper gra(poziom);
    gra.graj();
    return 0;
}
